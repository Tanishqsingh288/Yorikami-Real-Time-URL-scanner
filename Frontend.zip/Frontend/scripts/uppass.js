document.getElementById("updatePasswordForm").addEventListener("submit", async function (e) {
  e.preventDefault();
  alert("✅ Your Yorikami Password is successfully Updated. Please Check the Email for teh confirmation.")

  const newPassword = document.getElementById("newPassword").value;
  const guardCode = document.getElementById("guardCode").value;
  const token = localStorage.getItem("token");
  const sessionId = localStorage.getItem("sessionId");

  try {
    const res = await fetch("https://yorikamiscanner.duckdns.org/api/auth/reset-password", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
        "x-session-id": sessionId
      },
      body: JSON.stringify({ newPassword, guardCode })
    });

    const data = await res.json();
    document.getElementById("message").innerText = data.message || data.error;
  } catch (err) {
    document.getElementById("message").innerText = "Error updating password.";
  }
});
